import { Schema, Types, model } from "mongoose";


const TaskSchema = new Schema({
 title : {
    type : String,
},
status : {
    type : String,
    enum : ['pending', 'done', 'checked'],
    default : 'pending'
  },
chat : {
    type :  Types.ObjectId,
    ref : "Chats"
  }
}, {
    timestamps : true
})



export default model('Tasks', TaskSchema)