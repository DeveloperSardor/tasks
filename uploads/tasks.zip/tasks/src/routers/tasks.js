import { Router } from "express";
import { TaskContr } from "../controllers/tasks.js";
import managerCheck from '../middlewares/manager.js'
import workerCheck from '../middlewares/worker.js'

const router = Router();

router.get(`/:chat`, TaskContr.getTasks)
router.post(`/create`, managerCheck, TaskContr.createTaskAsManager)
router.put(`/done/:id`, workerCheck, TaskContr.TaskDoneAsWorker)
router.put(`/checked/:id`, managerCheck, TaskContr.TaskCheckedAsManager)
router.put(`/:id`, managerCheck, TaskContr.EditTaskTitleAsManager)
router.delete(`/:id`, managerCheck, TaskContr.DeleteTaskAsManager)

export default router;