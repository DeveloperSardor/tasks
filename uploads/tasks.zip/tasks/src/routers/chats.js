import { Router } from "express";
import { ChatsContr } from "../controllers/chats.js";
import managerCheck from '../middlewares/manager.js'
import workerCheck from '../middlewares/worker.js'


const router = Router();


router.post(`/`, ChatsContr.accessChat);
router.get(`/`, ChatsContr.fetchChats);
router.post(`/group`, ChatsContr.createGroupChat);
router.put(`/rename/:chat`, ChatsContr.renameGroup)
router.put(`/group/add-user`, ChatsContr.addToGroup);
router.put(`/group/remove`, ChatsContr.removeGroup)

export default router;
