import { errorMessage } from '../../utils/error-message.js'
import { JWT } from '../../utils/jwt.js';
import TaskModel from '../schemas/tasks.js'
import UserModel from '../schemas/users.js'
import ChatModel from '../schemas/chats.js'


export class TaskContr{
    constructor(){}



   static async getTasks(req, res){
    try {
        const  { chat } = req.params;
        const { status } = req.query;
        const findChat = await ChatModel.findById(chat);
        if(findChat == null){
            throw new Error(`Chat topilmaid!`)
        }
        if(chat){
            if(status){
                const task = await TaskModel.findOne({ chat, status});
                res.send({
                    status : 200,
                    message : `${status} - holatdagi vazifalar`,
                    success : true,
                    data : task
                })
            }else{
                const task = await TaskModel.findOne({ chat });
                res.send({
                    status : 200,
                    message : "Vazifalar",
                    success : true,
                    data : task
                })
            }
        }else{
            throw new Error(`Chat Id yuboring!`)
        }
    } catch (error) {
        res.send(errorMessage(error.message))
    }
   }

    static async createTaskAsManager(req, res){
        try {
            const { title, chat } = req.body;
            if(!title){
                throw new Error(`Taskni kiriting`)
            }else if(!chat){
                throw new Error(`Chatni yuboring!`)
            }
            const newTask = await TaskModel.create({ title, chat });
            res.send({
                status : 201,
                message : "Yangi vazifa muvofaqqiyatli qo'shildi",
                success : true,
                data : newTask
            })
        } catch (error) {
            res.send(errorMessage(error.message))
        }
    }

   
    static async TaskDoneAsWorker(req, res){
        try {
            const { id } = req.params;
            const findTask = await TaskModel.findById(id);
            if(findTask == null){
                throw new Error(`Vazifa topilmadi`)
            }
            const updated = await TaskModel.findByIdAndUpdate(id, { status : "done" })
             res.send({
                status : 200,
                message : `Vazifa bajarilgan holatiga o'tdi`,
                success : true,
                data : updated
             })
        } catch (error) {
            res.send(errorMessage(error.message));
        }
    }


    static async TaskCheckedAsManager(req, res){
        try {
            const { id } = req.params;
            const findTask = await TaskModel.findById(id);
            if(findTask == null){
                throw new Error(`Vazifa topilmadi`)
            }
            const updated = await TaskModel.findByIdAndUpdate(id, { status : 'checked' })
            res.send({
                status : 200,
                message : `Vazifa tekshirildi holatiga o'tdi`,
                success : true,
                data : updated
             })
        } catch (error) {
            res.send(errorMessage(error.message))
        }
    }


    static async EditTaskTitleAsManager(req, res){
        try {
            const { id } = req.params;
            const findTask = await TaskModel.findById(id);
            if(findTask == null){
                throw new Error(`Vazifa topilmadi`)
            }
            const { title } = req.body;
            if(!title){
                throw new Error(`Vazifa nomini kiriting`)
            }
            const editedTask = await TaskModel.findByIdAndUpdate(id, { title })
            res.send({
                status : 200,
                message : "Vazifa muvofaqqiyatli o'chirildi",
                success : true,
                data : editedTask
            })
        } catch (error) {
            res.send(errorMessage(error.message))
        }
    }

    static async DeleteTaskAsManager(req, res){
        try {
            const { id } = req.params;
            const findTask = await TaskModel.findById(id);
            if(findTask == null){
                throw new Error(`Vazifa topilmadi`)
            }
            const deletedTask = await TaskModel.findByIdAndDelete(id);
            res.send({
                status : 200,
                message : "Vazifa muvofaqqiyatli o'chirildi",
                success : true,
                data : deletedTask
            })
        } catch (error) {
            res.send(errorMessage(error.message))
        }
    }

}