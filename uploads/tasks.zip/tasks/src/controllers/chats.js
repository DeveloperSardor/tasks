import ChatModel from "../schemas/chats.js";
import UserModel from "../schemas/users.js";
import { errorMessage } from "../utils/error-message.js";
import { JWT } from "../utils/jwt.js";

export class ChatsContr {
  constructor() {}

  static async accessChat(req, res) {
    try {
      const { token } = req.headers;
      const { id } = JWT.VERIFY(token);
      const checkUser = await UserModel.findById(id);
      if(checkUser == null){
        throw new Error(`Token yaroqsiz!`)
      }
      const { user } = req.body;
      if (!user) {
        throw new Error(`user paramterti requestdan yuboring`);
      }
      var isChat = await ChatModel.find({
        isGroupChat: false,
        $and: [
          { users: { $elemMatch: { $eq: id } } },
          { users: { $elemMatch: { $eq: user } } },
        ],
      })
        .populate("users", "-password")
        .populate("latestMessage");

      isChat = await UserModel.populate(isChat, {
        path: "latestMessage.sender",
      });

      if (isChat.length > 0) {
        res.send(isChat[0]);
      } else {
        var chatData = {
          chatName: "sender",
          isGroupChat: false,
          users: [id, user],
        };
      }

      const createdChat = await ChatModel.create(chatData);
      const FullChat = await ChatModel.findOne({
        _id: createdChat._id,
      }).populate("users");
      res.send({
        chat: 200,
        message: "Chat",
        success: true,
        data: FullChat,
      });
    } catch (error) {
      res.send(errorMessage(error.message));
    }
  }

  static async fetchChats(req, res) {
    try {
      const { token } = req.headers;
      const id = JWT.VERIFY(token);
      const checkUser = await UserModel.findById(id);
      if(checkUser == null){
        throw new Error(`Token yaroqsiz!`)
      }
      ChatModel.find({ users: { $elemMatch: { $eq: id } } })
        .populate("users", "-password")
        .populate("groupAdmin", "-password")
        .populate("latestMessage")
        .sort({ updatedAt: -1 })
        .then(async (results) => {
          results = await UserModel.populate(results, {
            path: "latestMessage.sender",
          });
          res.status(200).send({
            status: 200,
            message: "Chats",
            success: true,
            data: results,
          });
        });
    } catch (error) {
      res.send(errorMessage(error.message));
    }
  }

  static async createGroupChat(req, res) {
    try {
      const { token } = req.headers;
      const { id } = JWT.VERIFY(token);
      const checkUser = await UserModel.findById(id);
      if(checkUser == null){
        throw new Error(`Token yaroqsiz!`)
      }
      if (!id || !req.body.chatName) {
        throw new Error("Iltimos barcha kerakli ma'lumotlarni yuboring");
      }
      var users = JSON.parse(req.body.users);
      if (users.length < 1) {
        throw new Error(`Chatda kamida ikki kichi bo'lish kerak`);
      }
      users.push(id);

      const groupChat = await ChatModel.create({
        chatName: req.body.chatName,
        users: users,
        isGroupChat: true,
        groupAdmin: id,
      });

      const fullGroupChat = await ChatModel.findOne({ _id: groupChat._id })
        .populate("users", "-password")
        .populate("groupAdmin", "-password");
      res.status(200).send({
        status: 200,
        message: "Chat",
        success: true,
        data: fullGroupChat,
      });
    } catch (error) {
      res.send(errorMessage(error.message));
    }
  }

  static async renameGroup(req, res) {
    try {
      const { chatName } = req.body;
      const { chatId } = req.params;
      const updatedChat = await ChatModel.findByIdAndUpdate(
        chatId,
        {
          chatName,
        },
        {
          new: true,
        }
      )
        .populate("users", "-password")
        .populate("groupAdmin", "-password");
      if (!updatedChat) {
        throw new Error(`Chat topilmadi`);
      } else {
        res.send({
          status: 200,
          message: "Chat o'zgartirildi",
          success: true,
          data: updatedChat,
        });
      }
    } catch (error) {
      res.send(errorMessage(error.message));
    }
  }

  static async addToGroup(req, res) {
    try {
      const { user, chat } = req.body;
      const added = await ChatModel.findByIdAndUpdate(
        chat,
        {
          $push: { users: user },
        },
        {
          new: true,
        }
      )
        .populate("users", "-password")
        .populate("groupAdmin", "-password");

      if (!added) {
        throw new Error(`Chat topilmadi!`);
      } else {
        res.send({
          status: 201,
          message: "Chatga yangi a'zo muvofaqqiyatli qo'shildi",
          success: true,
          data: added,
        });
      }
    } catch (error) {
      res.send(errorMessage(error.message));
    }
  }

  static async removeGroup(req, res) {
    try {
      const { user, chat } = req.body;
      const removed = await ChatModel.findByIdAndUpdate(
        chat,
        {
          $pull: { users: user },
        },
        {
          new: true,
        }
      )
        .populate("users", "-password")
        .populate("groupAdmin", "-password");

      if (!removed) {
        throw new Error(`Chat topilmadi`);
      } else {
        res.send({
          status: 200,
          message: "Chat muvofaqqiyatli o'chirildi",
          success: true,
          data: removed,
        });
      }
    } catch (error) {
      res.send(errorMessage(error.message));
    }
  }
}
